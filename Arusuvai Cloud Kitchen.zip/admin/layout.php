<?php
/**
 * Shared layout helpers for admin pages — renders sidebar + topbar.
 * Call admin_header() at the top, admin_footer() at the bottom.
 */

declare(strict_types=1);

require_once __DIR__ . '/backend/config.php';
require_once __DIR__ . '/backend/auth.php';
require_once __DIR__ . '/backend/csrf.php';
require_once __DIR__ . '/backend/functions.php';

auth_start();

function admin_header(string $title, string $active = ''): void
{
  $csrf = csrf_token();
  $navItems = [
    'dashboard' => ['Dashboard', 'dashboard.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>'],
    'hero' => ['Hero Section', 'hero-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>'],
    'menu' => ['Menu Manager', 'menu-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 11h18M5 11a7 7 0 0 1 14 0M12 18a2 2 0 0 0 2-2v-2h-4v2a2 2 0 0 0 2 2Z"/></svg>'],
    'subscription' => ['Meal Plans', 'subscription-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M8 4v4M16 4v4"/></svg>'],
    'corporate' => ['Corporate', 'corporate-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6"/></svg>'],
    'gallery' => ['Gallery', 'gallery-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>'],
    'testimonial' => ['Testimonials', 'testimonial-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 7h-9M14 17H5M17 7a3 3 0 1 0-6 0M7 17a3 3 0 1 0 6 0"/></svg>'],
    'faq' => ['FAQ', 'faq-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12" y2="17"/></svg>'],
    'business' => ['Business Details', 'business-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6"/></svg>'],
    'social' => ['Social Media', 'social-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/></svg>'],
    'seo' => ['SEO Settings', 'seo-manager.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>'],
    'settings' => ['Settings', 'settings.php', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>'],
  ];

  $user = $_SESSION['admin_user'] ?? 'admin';
  $initial = strtoupper(substr($user, 0, 1));

  $navHtml = '';
  foreach ($navItems as $key => [$label, $href, $icon]) {
    $cls = $key === $active ? 'active' : '';
    $navHtml .= "<a href=\"{$href}\" class=\"adm-nav__link {$cls}\">{$icon}<span>{$label}</span></a>";
  }

  echo <<<HTML
<!doctype html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf" content="{$csrf}">
  <title>{$title} — Arusuvai Admin</title>
  <link rel="icon" type="image/png" href="/logo.png">
  <link rel="stylesheet" href="/admin/assets/admin.css">
</head>
<body class="adm">
  <aside class="adm-sidebar" id="sidebar">
    <div class="adm-sidebar__brand">
      <img src="/logo.png" alt="Arusuvai">
      <div><h1>Arusuvai</h1><small>Admin Panel</small></div>
    </div>
    <nav class="adm-nav">
      <div class="adm-nav__section">Content</div>
      {$navHtml}
    </nav>
    <div class="adm-sidebar__foot">
      <a href="/admin/logout.php" class="btn-logout">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>
        Logout
      </a>
    </div>
  </aside>
  <div class="adm-overlay" id="overlay"></div>
  <div class="adm-main">
    <header class="adm-topbar">
      <div class="adm-flex">
        <button class="adm-menu-btn" id="menuBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button>
        <h2>{$title}</h2>
      </div>
      <div class="adm-topbar__right">
        <button class="adm-theme-toggle" id="themeToggle" aria-label="Toggle theme">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/></svg>
        </button>
        <div class="adm-user">
          <div class="adm-user__avatar">{$initial}</div>
          <span>{$user}</span>
        </div>
      </div>
    </header>
    <main class="adm-content">
HTML;
}

function admin_footer(): void
{
  echo <<<HTML
    </main>
  </div>
  <script src="/admin/assets/admin.js"></script>
HTML;
  // Extra page-specific script
  $extra = $GLOBALS['admin_extra_js'] ?? '';
  if ($extra) echo "<script src=\"{$extra}\"></script>\n";
  echo "</body></html>";
}

function set_admin_js(string $path): void
{
  $GLOBALS['admin_extra_js'] = $path;
}
