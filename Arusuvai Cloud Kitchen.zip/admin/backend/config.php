<?php
/**
 * Arusuvai Admin — Central configuration
 * All paths, security constants and defaults live here.
 */

declare(strict_types=1);

// ---- Paths ---------------------------------------------------------------
// Root of the project (one level above /admin)
define('ROOT_DIR', dirname(__DIR__));
// Data folder holding JSON files
define('DATA_DIR', ROOT_DIR . '/data');
// Uploads root
define('UPLOAD_DIR', ROOT_DIR . '/uploads');
// Admin folder
define('ADMIN_DIR', __DIR__);

// ---- Security -----------------------------------------------------------
// Session cookie settings (set before session_start)
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.use_strict_mode', '1');
if (!empty($_SERVER['HTTPS'])) {
    ini_set('session.cookie_secure', '1');
}

// Session inactivity timeout in seconds (30 minutes)
define('SESSION_TIMEOUT', 30 * 60);

// Brute-force protection: max attempts before lockout
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_SECONDS', 15 * 60);

// Upload limits
define('MAX_UPLOAD_BYTES', 4 * 1024 * 1024); // 4 MB
define('ALLOWED_IMAGE_MIME', ['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

// ---- Default admin credentials -----------------------------------------
// On first run, a data/admin.json is created with this hashed password.
// CHANGE THIS after first login via the dashboard.
define('DEFAULT_ADMIN_USER', 'admin');
define('DEFAULT_ADMIN_PASS', 'arusuvai123');

// ---- JSON data files ----------------------------------------------------
define('DATA_FILES', [
    'hero', 'business', 'menu', 'gallery', 'reviews',
    'faq', 'subscriptions', 'corporate', 'social', 'seo',
]);

// ---- Helper: base URL ---------------------------------------------------
function base_url(string $path = ''): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return rtrim($scheme . '://' . $host, '/') . '/' . ltrim($path, '/');
}

// ---- Error reporting (disable in production) ---------------------------
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
