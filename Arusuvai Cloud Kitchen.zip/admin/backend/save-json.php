<?php
/**
 * POST endpoint for saving JSON data from admin managers.
 * Expects: name (JSON key), data (JSON string), csrf_token.
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/functions.php';

auth_start();

header('Content-Type: application/json');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (!csrf_verify()) {
    http_response_code(403);
    echo json_encode(['error' => 'Invalid CSRF token']);
    exit;
}

$name = $_POST['name'] ?? '';
$data = $_POST['data'] ?? '';

if (!in_array($name, DATA_FILES, true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid data name']);
    exit;
}

$decoded = json_decode($data, true);
if (!is_array($decoded)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

if (save_json_file($name, $decoded)) {
    log_activity("Saved JSON: {$name}");
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Save failed']);
}
