<?php
/**
 * Reusable functions: JSON read/write with locking + backup, output escaping,
 * validation, activity logging, and image upload handling.
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';

/**
 * Output-escape a value for safe HTML rendering (XSS protection).
 */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * Read a JSON data file and return the decoded array.
 */
function load_json(string $name): array
{
    $file = DATA_DIR . '/' . $name . '.json';
    if (!file_exists($file)) return [];
    $raw = file_get_contents($file);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/**
 * Save a JSON data file safely:
 *  - creates a timestamped backup first
 *  - uses exclusive file locking
 *  - validates the JSON before committing
 *  - rolls back if the write fails
 * Returns true on success, false on failure.
 */
function save_json_file(string $name, array $data): bool
{
    if (!is_dir(DATA_DIR)) mkdir(DATA_DIR, 0775, true);
    $file = DATA_DIR . '/' . $name . '.json';

    // Backup existing file
    if (file_exists($file)) {
        $backup = DATA_DIR . '/.backup/' . $name . '_' . date('Ymd_His') . '.json';
        if (!is_dir(dirname($backup))) mkdir(dirname($backup), 0775, true);
        copy($file, $backup);
    }

    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) return false;

    // Validate round-trip
    if (json_decode($json, true) === null && json_last_error() !== JSON_ERROR_NONE) {
        return false;
    }

    $tmp = $file . '.tmp';
    $fp = fopen($tmp, 'w');
    if (!$fp) return false;
    if (flock($fp, LOCK_EX)) {
        fwrite($fp, $json);
        fflush($fp);
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    if (!file_exists($tmp)) return false;
    if (!rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

/**
 * Alias kept for clarity in managers.
 */
function save_json(string $name, array $data): bool
{
    return save_json_file($name, $data);
}

/**
 * Validate a string against a max length.
 */
function validate_string($value, int $max = 1000): string
{
    $value = trim((string) $value);
    return mb_substr($value, 0, $max);
}

/**
 * Validate an email address.
 */
function validate_email(string $email): string
{
    $email = trim($email);
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : '';
}

/**
 * Sanitise a filename to prevent directory traversal.
 */
function safe_filename(string $name): string
{
    $name = basename($name);
    $name = preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
    return $name;
}

/**
 * Append a line to the activity log.
 */
function log_activity(string $message): void
{
    if (!is_dir(DATA_DIR)) mkdir(DATA_DIR, 0775, true);
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n";
    file_put_contents(DATA_DIR . '/activity.log', $line, FILE_APPEND | LOCK_EX);
}

/**
 * Handle a single image upload: validates MIME, size, moves to target dir,
 * generates a thumbnail, and attempts WebP conversion.
 * Returns ['url' => ...] on success or ['error' => ...] on failure.
 */
function handle_upload(array $file, string $subdir): array
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['error' => 'Upload failed (code ' . $file['error'] . ')'];
    }
    if ($file['size'] > MAX_UPLOAD_BYTES) {
        return ['error' => 'File too large (max ' . (MAX_UPLOAD_BYTES / 1024 / 1024) . 'MB)'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, ALLOWED_IMAGE_MIME, true)) {
        return ['error' => 'Only JPG, PNG, WebP and GIF are allowed'];
    }

    $target_dir = UPLOAD_DIR . '/' . $subdir;
    if (!is_dir($target_dir)) mkdir($target_dir, 0775, true);

    $ext = match ($mime) {
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        default => 'bin',
    };
    $name = safe_filename(pathinfo($file['name'], PATHINFO_FILENAME));
    $filename = $name . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = $target_dir . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return ['error' => 'Could not save file'];
    }

    $url = '/uploads/' . $subdir . '/' . $filename;

    // Generate thumbnail (best-effort, requires GD)
    generate_thumbnail($dest, 400);

    // Attempt WebP conversion (best-effort)
    if ($ext !== 'webp' && function_exists('imagewebp')) {
        convert_to_webp($dest);
    }

    log_activity("Image uploaded: {$url}");
    return ['url' => $url];
}

/**
 * Generate a thumbnail next to the original (best-effort via GD).
 */
function generate_thumbnail(string $path, int $maxW): void
{
    if (!function_exists('imagecreatefromjpeg')) return;
    $info = @getimagesize($path);
    if (!$info) return;
    [$w, $h, $type] = $info;
    if ($w <= $maxW) return;

    $src = match ($type) {
        IMAGETYPE_JPEG => @imagecreatefromjpeg($path),
        IMAGETYPE_PNG => @imagecreatefrompng($path),
        IMAGETYPE_WEBP => @imagecreatefromwebp($path),
        IMAGETYPE_GIF => @imagecreatefromgif($path),
        default => null,
    };
    if (!$src) return;

    $ratio = $maxW / $w;
    $tw = (int) ($w * $ratio);
    $th = (int) ($h * $ratio);
    $thumb = imagecreatetruecolor($tw, $th);
    imagecopyresampled($thumb, $src, 0, 0, 0, 0, $tw, $th, $w, $h);

    $dir = dirname($path);
    $base = pathinfo($path, PATHINFO_FILENAME);
    $thumbPath = $dir . '/' . $base . '_thumb.jpg';
    imagejpeg($thumb, $thumbPath, 85);
    imagedestroy($src);
    imagedestroy($thumb);
}

/**
 * Convert an image to WebP (best-effort via GD).
 */
function convert_to_webp(string $path): void
{
    $info = @getimagesize($path);
    if (!$info) return;
    [$w, $h, $type] = $info;
    $src = match ($type) {
        IMAGETYPE_JPEG => @imagecreatefromjpeg($path),
        IMAGETYPE_PNG => @imagecreatefrompng($path),
        IMAGETYPE_GIF => @imagecreatefromgif($path),
        default => null,
    };
    if (!$src) return;
    $webpPath = preg_replace('/\.(jpg|jpeg|png|gif)$/i', '.webp', $path);
    imagewebp($src, $webpPath, 85);
    imagedestroy($src);
}

/**
 * Delete an uploaded file from disk (with path traversal guard).
 */
function delete_upload(string $url): bool
{
    $path = ROOT_DIR . $url;
    $real = realpath($path);
    $uploadReal = realpath(UPLOAD_DIR);
    if ($real === false || $uploadReal === false) return false;
    if (strpos($real, $uploadReal) !== 0) return false; // must be inside uploads
    return @unlink($real);
}
