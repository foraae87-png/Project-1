<?php
/**
 * POST endpoint for image uploads (drag & drop or file input).
 * Expects: file (multipart), subdir, csrf_token.
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/functions.php';

auth_start();

header('Content-Type: application/json');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (!csrf_verify()) {
    http_response_code(403);
    echo json_encode(['error' => 'Invalid CSRF token']);
    exit;
}

if (empty($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No file provided']);
    exit;
}

$subdir = $_POST['subdir'] ?? '';
$allowed = ['hero', 'gallery', 'menu', 'testimonials'];
if (!in_array($subdir, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid upload directory']);
    exit;
}

$result = handle_upload($_FILES['file'], $subdir);
if (isset($result['error'])) {
    http_response_code(400);
    echo json_encode($result);
    exit;
}

echo json_encode($result);
