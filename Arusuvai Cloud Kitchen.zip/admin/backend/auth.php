<?php
/**
 * Arusuvai Admin — Authentication, sessions, brute-force protection.
 * Passwords are stored only as hashes in data/admin.json — never in HTML/CSS/JS.
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

/**
 * Start a secure session (call once at the top of every admin page).
 */
function auth_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name('arusuvai_admin');
        session_start();
    }

    // Auto-logout after inactivity
    if (!empty($_SESSION['last_activity'])) {
        if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
            session_destroy();
            session_start();
            session_regenerate_id(true);
            return;
        }
    }
    $_SESSION['last_activity'] = time();
}

/**
 * Is the current user logged in?
 */
function is_logged_in(): bool
{
    return !empty($_SESSION['admin_user']);
}

/**
 * Require login — redirect to login page if not authenticated.
 */
function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: /admin/login.php');
        exit;
    }
}

/**
 * Attempt a login. Returns true on success, false otherwise.
 * Implements brute-force protection via a file-based attempt counter.
 */
function attempt_login(string $username, string $password): bool
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $lock_file = DATA_DIR . '/.login_lock_' . md5($ip);

    // Check lockout
    if (file_exists($lock_file)) {
        $lock = (int) file_get_contents($lock_file);
        if (time() - $lock < LOGIN_LOCKOUT_SECONDS) {
            return false; // still locked
        }
        @unlink($lock_file);
    }

    $admin = load_admin();
    if ($username === $admin['username'] && password_verify($password, $admin['password_hash'])) {
        // Success — regenerate session, clear attempts
        session_regenerate_id(true);
        $_SESSION['admin_user'] = $username;
        $_SESSION['login_time'] = time();
        $_SESSION['last_activity'] = time();
        @unlink($lock_file);
        log_activity("Login success: {$username}");
        return true;
    }

    // Failure — increment attempts
    $attempts_file = DATA_DIR . '/.login_attempts_' . md5($ip);
    $attempts = file_exists($attempts_file) ? (int) file_get_contents($attempts_file) : 0;
    $attempts++;
    file_put_contents($attempts_file, (string) $attempts, LOCK_EX);

    if ($attempts >= MAX_LOGIN_ATTEMPTS) {
        file_put_contents($lock_file, (string) time(), LOCK_EX);
        @unlink($attempts_file);
        log_activity("Login lockout triggered for IP: {$ip}");
    }

    log_activity("Login failed: {$username} from {$ip}");
    return false;
}

/**
 * Log out — destroy the session completely.
 */
function logout(): void
{
    $_SESSION = [];
    $params = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires' => time() - 42000,
        'path' => $params['path'],
        'domain' => $params['domain'],
        'secure' => $params['secure'],
        'httponly' => $params['httponly'],
        'samesite' => $params['samesite'] ?? 'Lax',
    ]);
    session_destroy();
}

/**
 * Load admin credentials from JSON (creates defaults on first run).
 */
function load_admin(): array
{
    $file = DATA_DIR . '/admin.json';
    if (!file_exists($file)) {
        $default = [
            'username' => DEFAULT_ADMIN_USER,
            'password_hash' => password_hash(DEFAULT_ADMIN_PASS, PASSWORD_DEFAULT),
        ];
        save_json_file('admin', $default);
        return $default;
    }
    return json_decode(file_get_contents($file), true) ?: [];
}

/**
 * Update admin credentials.
 */
function update_admin(string $username, string $newPassword): bool
{
    $admin = [
        'username' => $username,
        'password_hash' => password_hash($newPassword, PASSWORD_DEFAULT),
    ];
    return save_json_file('admin', $admin);
}
