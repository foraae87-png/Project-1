<?php
/** Business details editor — phone, WhatsApp, email, hours, address, map. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('business');
$default = [
  'name' => 'Arusuvai',
  'tagline' => 'Cloud Kitchen',
  'whatsapp' => '917550161906',
  'phone' => '918270201301',
  'email' => 'hello@arusuvai.in',
  'instagram' => 'https://instagram.com/arusuvai',
  'facebook' => 'https://facebook.com/arusuvai',
  'address' => 'Arusuvai Cloud Kitchen',
  'hours' => 'Mon–Sun · 7:00 AM – 10:00 PM',
  'followers' => '45.5K+',
];
foreach ($default as $k => $v) if (!isset($data[$k])) $data[$k] = $v;

admin_header('Business Details', 'business');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>Business Details</h3>
  <p>Update your contact information, hours and social links. These appear across the website.</p>
</div>

<div class="adm-card" style="max-width:680px">
  <form id="bizForm">
    <div class="adm-grid adm-grid--2">
      <div class="adm-form-group">
        <label>Business Name</label>
        <input class="adm-input" data-field="name" value="<?= e($data['name']) ?>">
      </div>
      <div class="adm-form-group">
        <label>Tagline</label>
        <input class="adm-input" data-field="tagline" value="<?= e($data['tagline']) ?>">
      </div>
    </div>
    <div class="adm-grid adm-grid--2">
      <div class="adm-form-group">
        <label>WhatsApp Number (with country code)</label>
        <input class="adm-input" data-field="whatsapp" value="<?= e($data['whatsapp']) ?>">
        <div class="adm-hint">e.g. 917550161906</div>
      </div>
      <div class="adm-form-group">
        <label>Phone Number (with country code)</label>
        <input class="adm-input" data-field="phone" value="<?= e($data['phone']) ?>">
      </div>
    </div>
    <div class="adm-form-group">
      <label>Email</label>
      <input class="adm-input" data-field="email" value="<?= e($data['email']) ?>">
    </div>
    <div class="adm-grid adm-grid--2">
      <div class="adm-form-group">
        <label>Instagram URL</label>
        <input class="adm-input" data-field="instagram" value="<?= e($data['instagram']) ?>">
      </div>
      <div class="adm-form-group">
        <label>Facebook URL</label>
        <input class="adm-input" data-field="facebook" value="<?= e($data['facebook']) ?>">
      </div>
    </div>
    <div class="adm-form-group">
      <label>Address / Map Query</label>
      <input class="adm-input" data-field="address" value="<?= e($data['address']) ?>">
      <div class="adm-hint">Used for Google Maps embed.</div>
    </div>
    <div class="adm-grid adm-grid--2">
      <div class="adm-form-group">
        <label>Business Hours</label>
        <input class="adm-input" data-field="hours" value="<?= e($data['hours']) ?>">
      </div>
      <div class="adm-form-group">
        <label>Instagram Followers Label</label>
        <input class="adm-input" data-field="followers" value="<?= e($data['followers']) ?>">
      </div>
    </div>
    <button type="submit" class="adm-btn adm-btn--primary adm-mt">Save Changes</button>
  </form>
</div>

<script>
const bizData = <?= json_encode($data) ?>;
document.getElementById('bizForm').addEventListener('submit', async (e) => {
  e.preventDefault()
  ;['name','tagline','whatsapp','phone','email','instagram','facebook','address','hours','followers'].forEach(f => {
    bizData[f] = document.querySelector(`[data-field="${f}"]`).value
  })
  await saveAndToast('business', bizData, e.target.querySelector('button[type="submit"]'))
})
</script>
<?php admin_footer(); ?>
