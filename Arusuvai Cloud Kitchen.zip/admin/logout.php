<?php
/**
 * Admin logout — destroys the session completely.
 */

declare(strict_types=1);

require_once __DIR__ . '/backend/config.php';
require_once __DIR__ . '/backend/auth.php';
require_once __DIR__ . '/backend/functions.php';

auth_start();
log_activity('Logout: ' . ($_SESSION['admin_user'] ?? 'unknown'));
logout();
header('Location: /admin/login.php');
exit;
