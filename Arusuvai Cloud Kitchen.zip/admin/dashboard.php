<?php
/**
 * Admin dashboard — overview of content, stats and quick links.
 */

declare(strict_types=1);

require_once __DIR__ . '/layout.php';
require_login();

// Gather quick stats from JSON files
$business = load_json('business');
$menu = load_json('menu');
$gallery = load_json('gallery');
$reviews = load_json('reviews');
$faq = load_json('faq');

$menuCount = count($menu['items'] ?? []);
$galleryCount = count($gallery['items'] ?? []);
$reviewCount = count($reviews['items'] ?? []);
$faqCount = count($faq['items'] ?? []);

admin_header('Dashboard', 'dashboard');
?>
<div class="adm-content__head">
  <h3>Welcome back, <?= e($_SESSION['admin_user'] ?? 'Admin') ?></h3>
  <p>Here's an overview of your Arusuvai Cloud Kitchen website content.</p>
</div>

<div class="adm-grid adm-grid--4">
  <div class="adm-card">
    <div class="adm-stat__icon adm-stat__icon--primary"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 11h18M5 11a7 7 0 0 1 14 0M12 18a2 2 0 0 0 2-2v-2h-4v2a2 2 0 0 0 2 2Z"/></svg></div>
    <div class="adm-stat__num"><?= $menuCount ?></div>
    <div class="adm-stat__label">Menu Items</div>
  </div>
  <div class="adm-card">
    <div class="adm-stat__icon adm-stat__icon--accent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg></div>
    <div class="adm-stat__num"><?= $galleryCount ?></div>
    <div class="adm-stat__label">Gallery Photos</div>
  </div>
  <div class="adm-card">
    <div class="adm-stat__icon adm-stat__icon--blue"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 7h-9M14 17H5M17 7a3 3 0 1 0-6 0M7 17a3 3 0 1 0 6 0"/></svg></div>
    <div class="adm-stat__num"><?= $reviewCount ?></div>
    <div class="adm-stat__label">Reviews</div>
  </div>
  <div class="adm-card">
    <div class="adm-stat__icon adm-stat__icon--purple"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/></svg></div>
    <div class="adm-stat__num"><?= $faqCount ?></div>
    <div class="adm-stat__label">FAQ Entries</div>
  </div>
</div>

<div class="adm-grid adm-grid--2 adm-mt-2">
  <div class="adm-card">
    <div class="adm-flex adm-flex--between adm-mb">
      <h4 style="font-family:'Poppins';font-weight:600">Quick Actions</h4>
    </div>
    <div class="adm-grid adm-grid--2">
      <a href="/admin/hero-manager.php" class="adm-btn adm-btn--ghost">Edit Hero</a>
      <a href="/admin/menu-manager.php" class="adm-btn adm-btn--ghost">Manage Menu</a>
      <a href="/admin/gallery-manager.php" class="adm-btn adm-btn--ghost">Add Photos</a>
      <a href="/admin/business-manager.php" class="adm-btn adm-btn--ghost">Business Info</a>
      <a href="/admin/seo-manager.php" class="adm-btn adm-btn--ghost">SEO Settings</a>
      <a href="/admin/social-manager.php" class="adm-btn adm-btn--ghost">Social Links</a>
    </div>
  </div>
  <div class="adm-card">
    <h4 style="font-family:'Poppins';font-weight:600;margin-bottom:1rem">Business Snapshot</h4>
    <table class="adm-table">
      <tr><td>WhatsApp</td><td><?= e($business['whatsapp'] ?? '—') ?></td></tr>
      <tr><td>Phone</td><td><?= e($business['phone'] ?? '—') ?></td></tr>
      <tr><td>Email</td><td><?= e($business['email'] ?? '—') ?></td></tr>
      <tr><td>Instagram</td><td><?= e($business['instagram'] ?? '—') ?></td></tr>
      <tr><td>Hours</td><td><?= e($business['hours'] ?? '—') ?></td></tr>
    </table>
    <a href="/admin/business-manager.php" class="adm-btn adm-btn--primary adm-mt">Edit Details</a>
  </div>
</div>

<div class="adm-card adm-mt-2">
  <h4 style="font-family:'Poppins';font-weight:600;margin-bottom:1rem">Recent Activity</h4>
  <?php
  $logFile = DATA_DIR . '/activity.log';
  if (file_exists($logFile)):
    $lines = array_slice(array_reverse(file($logFile, FILE_IGNORE_NEW_LINES)), 0, 8);
    foreach ($lines as $line) echo '<div style="font-size:0.85rem;color:var(--ad-muted);padding:0.4rem 0;border-bottom:1px solid var(--ad-border)">' . e($line) . '</div>';
  else:
    echo '<p class="adm-empty">No activity yet.</p>';
  endif;
  ?>
</div>

<?php admin_footer(); ?>
