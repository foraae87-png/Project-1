<?php
/** Social media links manager. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('social');
$default = [
  'instagram' => 'https://instagram.com/arusuvai',
  'facebook' => 'https://facebook.com/arusuvai',
  'whatsapp' => '917550161906',
  'instagram_followers' => '45.5K+',
];
foreach ($default as $k => $v) if (!isset($data[$k])) $data[$k] = $v;

admin_header('Social Media', 'social');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>Social Media</h3>
  <p>Manage your social media links and follower counts.</p>
</div>

<div class="adm-card" style="max-width:560px">
  <form id="socialForm">
    <div class="adm-form-group">
      <label>Instagram URL</label>
      <input class="adm-input" data-field="instagram" value="<?= e($data['instagram']) ?>">
    </div>
    <div class="adm-form-group">
      <label>Instagram Followers Label</label>
      <input class="adm-input" data-field="instagram_followers" value="<?= e($data['instagram_followers']) ?>">
    </div>
    <div class="adm-form-group">
      <label>Facebook URL</label>
      <input class="adm-input" data-field="facebook" value="<?= e($data['facebook']) ?>">
    </div>
    <div class="adm-form-group">
      <label>WhatsApp Number</label>
      <input class="adm-input" data-field="whatsapp" value="<?= e($data['whatsapp']) ?>">
    </div>
    <button type="submit" class="adm-btn adm-btn--primary adm-mt">Save Changes</button>
  </form>
</div>

<script>
const socialData = <?= json_encode($data) ?>;
document.getElementById('socialForm').addEventListener('submit', async (e) => {
  e.preventDefault()
  ;['instagram','instagram_followers','facebook','whatsapp'].forEach(f => {
    socialData[f] = document.querySelector(`[data-field="${f}"]`).value
  })
  await saveAndToast('social', socialData, e.target.querySelector('button[type="submit"]'))
})
</script>
<?php admin_footer(); ?>
