<?php
/** Gallery manager — upload, caption and remove gallery photos. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('gallery');
if (!isset($data['items'])) $data['items'] = [];

admin_header('Gallery Manager', 'gallery');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>Gallery Manager</h3>
  <p>Upload photos and assign categories. Uploaded images appear instantly on the gallery page.</p>
</div>

<div class="adm-card adm-mb">
  <div class="adm-dropzone" id="dropzone">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
    <p>Drag & drop or click to upload gallery images</p>
    <input type="file" id="fileInput" accept="image/*" multiple hidden>
  </div>
</div>

<div class="adm-card">
  <div class="adm-flex adm-flex--between adm-mb">
    <h4 style="font-family:'Poppins';font-weight:600">Gallery Photos (<?= count($data['items']) ?>)</h4>
    <button class="adm-btn adm-btn--primary" id="saveBtn">Save Changes</button>
  </div>
  <div id="listContainer"></div>
</div>

<script>
const galData = <?= json_encode($data) ?>;
const fields = ['src','caption','category'];
const cats = ['breakfast','meals','snacks','kitchen'];

function renderItem(item, i) {
  return `
    <div class="adm-flex adm-mb">
      <img src="${item.src || ''}" style="width:60px;height:60px;border-radius:8px;object-fit:cover" onerror="this.style.display='none'">
      <input class="adm-input" data-field="src" placeholder="Image URL" value="${item.src || ''}" style="flex:1">
    </div>
    <div class="adm-grid adm-grid--2">
      <input class="adm-input" data-field="caption" placeholder="Caption" value="${item.caption || ''}">
      <select class="adm-select" data-field="category">
        ${cats.map(c => `<option value="${c}" ${item.category===c?'selected':''}>${c.charAt(0).toUpperCase()+c.slice(1)}</option>`).join('')}
      </select>
    </div>
  `
}

function refresh() { renderList('listContainer', galData.items, fields, renderItem) }
refresh()

document.getElementById('saveBtn').addEventListener('click', async (e) => {
  galData.items = collectList('listContainer', fields)
  await saveAndToast('gallery', galData, e.target)
})

initDropzone('dropzone', 'fileInput', 'gallery', (url) => {
  galData.items.push({ src: url, caption: '', category: 'meals' })
  refresh()
})
</script>
<?php admin_footer(); ?>
