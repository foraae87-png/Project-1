<?php
/** Settings — change admin password and view security info. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error = 'Invalid session token. Please try again.';
    } else {
        $current = $_POST['current_pass'] ?? '';
        $newUser = trim($_POST['username'] ?? '');
        $newPass = $_POST['new_pass'] ?? '';
        $confirm = $_POST['confirm_pass'] ?? '';

        $admin = load_admin();
        if (!password_verify($current, $admin['password_hash'])) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($newPass) < 8) {
            $error = 'New password must be at least 8 characters.';
        } elseif ($newPass !== $confirm) {
            $error = 'New passwords do not match.';
        } elseif (empty($newUser)) {
            $error = 'Username cannot be empty.';
        } else {
            if (update_admin($newUser, $newPass)) {
                $_SESSION['admin_user'] = $newUser;
                log_activity("Password changed for: {$newUser}");
                $success = 'Credentials updated successfully.';
            } else {
                $error = 'Failed to save. Please try again.';
            }
        }
    }
}

admin_header('Settings', 'dashboard');
?>
<div class="adm-content__head">
  <h3>Settings</h3>
  <p>Change your admin username and password. Passwords are stored only as secure hashes.</p>
</div>

<?php if ($success): ?>
  <div class="adm-toast adm-toast--success show" style="position:static;transform:none;opacity:1"><?= e($success) ?></div>
<?php endif; ?>
<?php if ($error): ?>
  <div class="adm-toast adm-toast--error show" style="position:static;transform:none;opacity:1"><?= e($error) ?></div>
<?php endif; ?>

<div class="adm-card" style="max-width:560px">
  <form method="post">
    <?= csrf_field() ?>
    <div class="adm-form-group">
      <label>Username</label>
      <input class="adm-input" type="text" name="username" value="<?= e($_SESSION['admin_user'] ?? 'admin') ?>" required>
    </div>
    <div class="adm-form-group">
      <label>Current Password</label>
      <input class="adm-input" type="password" name="current_pass" required>
    </div>
    <div class="adm-form-group">
      <label>New Password (min 8 characters)</label>
      <input class="adm-input" type="password" name="new_pass" required minlength="8">
    </div>
    <div class="adm-form-group">
      <label>Confirm New Password</label>
      <input class="adm-input" type="password" name="confirm_pass" required>
    </div>
    <button type="submit" class="adm-btn adm-btn--primary">Update Credentials</button>
  </form>
</div>

<div class="adm-card adm-mt-2" style="max-width:560px">
  <h4 style="font-family:'Poppins';font-weight:600;margin-bottom:0.8rem">Security Features</h4>
  <table class="adm-table">
    <tr><td>CSRF Protection</td><td><span class="adm-badge adm-badge--green">Active</span></td></tr>
    <tr><td>Session Timeout</td><td>30 minutes</td></tr>
    <tr><td>Brute Force Protection</td><td><span class="adm-badge adm-badge--green">Active</span></td></tr>
    <tr><td>Password Hashing</td><td>PHP password_hash()</td></tr>
    <tr><td>Image Upload Validation</td><td><span class="adm-badge adm-badge--green">Active</span></td></tr>
    <tr><td>JSON Backup & Rollback</td><td><span class="adm-badge adm-badge--green">Active</span></td></tr>
  </table>
</div>
<?php admin_footer(); ?>
