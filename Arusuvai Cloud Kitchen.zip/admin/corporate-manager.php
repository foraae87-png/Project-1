<?php
/** Corporate orders manager — edit corporate package details. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('corporate');
$default = ['packages' => []];
if (!isset($data['packages'])) $data['packages'] = [];
if (!count($data['packages'])) {
  $data['packages'] = [
    ['name'=>'Daily Lunch','price'=>'120','unit'=>'/person/day','desc'=>'Ongoing lunch subscription','features'=>"Rotating South Indian menu\nVeg & non-veg options\nDelivered hot, on schedule\nWeekly invoicing"],
    ['name'=>'Team Catering','price'=>'150','unit'=>'/person','desc'=>'One-time or recurring event catering','featured'=>true,'features'=>"Full banana leaf or buffet spread\n10 to 200+ people\nCustom menu selection\nOn-site setup available\nEco-friendly packaging"],
    ['name'=>'Bulk Orders','price'=>'Custom','unit'=>'','desc'=>'Large quantity food for events','features'=>"Any quantity, any cuisine\n48-hour advance booking\nBulk pricing discounts\nDedicated coordinator"],
  ];
}

admin_header('Corporate Orders', 'corporate');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>Corporate Packages</h3>
  <p>Edit the packages shown on the Corporate Orders page.</p>
</div>

<div class="adm-card">
  <div class="adm-flex adm-flex--between adm-mb">
    <h4 style="font-family:'Poppins';font-weight:600">Packages (<?= count($data['packages']) ?>)</h4>
    <button class="adm-btn adm-btn--primary" id="addBtn">+ Add Package</button>
  </div>
  <div id="listContainer"></div>
  <button class="adm-btn adm-btn--primary adm-mt-2" id="saveBtn">Save All Changes</button>
</div>

<script>
const corpData = <?= json_encode($data) ?>;
const fields = ['name','price','unit','desc','features','featured'];

function renderItem(item, i) {
  return `
    <div class="adm-grid adm-grid--2">
      <input class="adm-input" data-field="name" placeholder="Package name" value="${item.name || ''}">
      <input class="adm-input" data-field="price" placeholder="Price (₹)" value="${item.price || ''}">
    </div>
    <div class="adm-grid adm-grid--2 adm-mt">
      <input class="adm-input" data-field="unit" placeholder="Unit (e.g. /person)" value="${item.unit || ''}">
      <input class="adm-input" data-field="desc" placeholder="Short description" value="${item.desc || ''}">
    </div>
    <textarea class="adm-textarea adm-mt" data-field="features" placeholder="One feature per line">${item.features || ''}</textarea>
    <label class="adm-flex adm-mt" style="gap:0.4rem;font-size:0.85rem">
      <input type="checkbox" data-field="featured" ${item.featured?'checked':''}> Featured package (highlighted)
    </label>
  `
}

renderList('listContainer', corpData.packages, fields, renderItem)
addItemClick('addBtn', corpData.packages, () => ({name:'',price:'',unit:'',desc:'',features:'',featured:false}), 'listContainer', renderItem)

document.getElementById('saveBtn').addEventListener('click', async (e) => {
  const items = collectList('listContainer', fields)
  items.forEach(it => it.featured = it.featured === true || it.featured === 'on' || it.featured === 'true')
  corpData.packages = items
  await saveAndToast('corporate', corpData, e.target)
})
</script>
<?php admin_footer(); ?>
