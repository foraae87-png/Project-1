<?php
/** SEO settings manager — meta tags, Open Graph, structured data. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('seo');
$default = [
  'site_title' => 'Arusuvai Cloud Kitchen — Authentic South Indian Homemade Meals',
  'meta_description' => 'Fresh homemade South Indian food — daily meals, meal subscriptions, catering and corporate lunch services.',
  'og_title' => 'Arusuvai Cloud Kitchen — Authentic South Indian Homemade Meals',
  'og_description' => 'Fresh homemade South Indian food delivered with care. Daily meals, subscriptions, catering & corporate orders.',
  'keywords' => 'south indian food, homemade food, cloud kitchen, meal subscription, catering, corporate lunch, dosa, idli, meals',
  'og_image' => '/logo.png',
  'twitter_handle' => '@arusuvai',
];
foreach ($default as $k => $v) if (!isset($data[$k])) $data[$k] = $v;

admin_header('SEO Settings', 'seo');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>SEO Settings</h3>
  <p>Control how your site appears in search engines and social media shares.</p>
</div>

<div class="adm-card" style="max-width:680px">
  <form id="seoForm">
    <div class="adm-form-group">
      <label>Site Title</label>
      <input class="adm-input" data-field="site_title" value="<?= e($data['site_title']) ?>">
    </div>
    <div class="adm-form-group">
      <label>Meta Description</label>
      <textarea class="adm-textarea" data-field="meta_description"><?= e($data['meta_description']) ?></textarea>
      <div class="adm-hint">Keep under 160 characters for best results.</div>
    </div>
    <div class="adm-form-group">
      <label>Keywords (comma-separated)</label>
      <input class="adm-input" data-field="keywords" value="<?= e($data['keywords']) ?>">
    </div>
    <div class="adm-form-group">
      <label>Open Graph Title</label>
      <input class="adm-input" data-field="og_title" value="<?= e($data['og_title']) ?>">
    </div>
    <div class="adm-form-group">
      <label>Open Graph Description</label>
      <textarea class="adm-textarea" data-field="og_description"><?= e($data['og_description']) ?></textarea>
    </div>
    <div class="adm-form-group">
      <label>Open Graph Image URL</label>
      <input class="adm-input" data-field="og_image" value="<?= e($data['og_image']) ?>">
    </div>
    <div class="adm-form-group">
      <label>Twitter Handle</label>
      <input class="adm-input" data-field="twitter_handle" value="<?= e($data['twitter_handle']) ?>">
    </div>
    <button type="submit" class="adm-btn adm-btn--primary adm-mt">Save Changes</button>
  </form>
</div>

<script>
const seoData = <?= json_encode($data) ?>;
document.getElementById('seoForm').addEventListener('submit', async (e) => {
  e.preventDefault()
  ;['site_title','meta_description','keywords','og_title','og_description','og_image','twitter_handle'].forEach(f => {
    seoData[f] = document.querySelector(`[data-field="${f}"]`).value
  })
  await saveAndToast('seo', seoData, e.target.querySelector('button[type="submit"]'))
})
</script>
<?php admin_footer(); ?>
