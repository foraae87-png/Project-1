/* Arusuvai Admin — shared JS: sidebar, theme, toast, save helpers */

// ---- Theme ----
function initTheme() {
  const saved = localStorage.getItem('arusuvai-theme') || 'dark'
  document.documentElement.setAttribute('data-theme', saved)
  const toggle = document.getElementById('themeToggle')
  if (toggle) {
    toggle.addEventListener('click', () => {
      const cur = document.documentElement.getAttribute('data-theme')
      const next = cur === 'dark' ? 'light' : 'dark'
      document.documentElement.setAttribute('data-theme', next)
      localStorage.setItem('arusuvai-theme', next)
    })
  }
}

// ---- Sidebar (mobile) ----
function initSidebar() {
  const btn = document.getElementById('menuBtn')
  const sidebar = document.getElementById('sidebar')
  const overlay = document.getElementById('overlay')
  if (!btn) return
  const open = () => { sidebar.classList.add('open'); overlay.classList.add('show') }
  const close = () => { sidebar.classList.remove('open'); overlay.classList.remove('show') }
  btn.addEventListener('click', open)
  overlay.addEventListener('click', close)
}

// ---- Toast ----
function toast(msg, type = 'success') {
  let t = document.querySelector('.adm-toast')
  if (!t) {
    t = document.createElement('div')
    t.className = 'adm-toast'
    document.body.appendChild(t)
  }
  t.className = `adm-toast adm-toast--${type}`
  t.textContent = msg
  requestAnimationFrame(() => t.classList.add('show'))
  clearTimeout(t._timer)
  t._timer = setTimeout(() => t.classList.remove('show'), 2800)
}

// ---- Save JSON helper ----
async function saveJSON(name, data) {
  const csrf = document.querySelector('meta[name="csrf"]')?.content || ''
  const res = await fetch('/admin/backend/save-json.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      csrf_token: csrf,
      name: name,
      data: JSON.stringify(data),
    }),
  })
  return res.json()
}

// ---- Upload helper ----
async function uploadFile(file, subdir) {
  const csrf = document.querySelector('meta[name="csrf"]')?.content || ''
  const fd = new FormData()
  fd.append('file', file)
  fd.append('subdir', subdir)
  fd.append('csrf_token', csrf)
  const res = await fetch('/admin/backend/upload.php', { method: 'POST', body: fd })
  return res.json()
}

// ---- Drag & drop ----
function initDropzone(zoneId, inputId, subdir, onUpload) {
  const zone = document.getElementById(zoneId)
  const input = document.getElementById(inputId)
  if (!zone) return
  const handle = (files) => {
    [...files].forEach(async (file) => {
      const res = await uploadFile(file, subdir)
      if (res.url) { toast('Image uploaded'); onUpload(res.url) }
      else toast(res.error || 'Upload failed', 'error')
    })
  }
  zone.addEventListener('click', () => input.click())
  input.addEventListener('change', () => handle(input.files))
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('dragover') })
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'))
  zone.addEventListener('drop', (e) => {
    e.preventDefault(); zone.classList.remove('dragover')
    handle(e.dataTransfer.files)
  })
}

// ---- Boot ----
document.addEventListener('DOMContentLoaded', () => {
  initTheme()
  initSidebar()
})
