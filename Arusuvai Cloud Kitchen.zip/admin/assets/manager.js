/* Arusuvai Admin — shared manager JS for list-based editors */

// Generic save-and-toast
async function saveAndToast(name, data, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…' }
  const res = await saveJSON(name, data)
  if (btn) { btn.disabled = false; btn.textContent = 'Save Changes' }
  if (res.success) toast('Saved successfully')
  else toast(res.error || 'Save failed', 'error')
  return res
}

// Render a dynamic list of items with add/remove
function renderList(containerId, items, fields, renderItem) {
  const container = document.getElementById(containerId)
  container.innerHTML = ''
  if (!items.length) {
    container.innerHTML = '<p class="adm-empty">No items yet. Click "Add" to create one.</p>'
    return
  }
  items.forEach((item, i) => {
    const row = document.createElement('div')
    row.className = 'adm-list-item'
    row.innerHTML = `
      <div class="adm-list-item__body">${renderItem(item, i)}</div>
      <div class="adm-list-item__actions">
        <button type="button" class="adm-icon-btn adm-icon-btn--del" data-del="${i}" title="Delete">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
      </div>`
    container.appendChild(row)
  })
  container.querySelectorAll('[data-del]').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.del)
      items.splice(idx, 1)
      renderList(containerId, items, fields, renderItem)
    })
  })
}

// Add item button
function addItemClick(btnId, items, factory, containerId, renderItem) {
  const btn = document.getElementById(btnId)
  if (!btn) return
  btn.addEventListener('click', () => {
    items.push(factory())
    renderList(containerId, items, [], renderItem)
  })
}

// Read field values from rendered list back into items array
function collectList(containerId, fields) {
  const container = document.getElementById(containerId)
  const rows = container.querySelectorAll('.adm-list-item')
  const items = []
  rows.forEach(row => {
    const obj = {}
    fields.forEach(f => {
      const el = row.querySelector(`[data-field="${f}"]`)
      obj[f] = el ? el.value : ''
    })
    items.push(obj)
  })
  return items
}
