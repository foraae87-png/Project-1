<?php
/** FAQ manager — add/edit/remove frequently asked questions. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('faq');
if (!isset($data['items'])) $data['items'] = [];

admin_header('FAQ Manager', 'faq');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>FAQ Manager</h3>
  <p>Edit the questions and answers shown on your FAQ and homepage sections.</p>
</div>

<div class="adm-card">
  <div class="adm-flex adm-flex--between adm-mb">
    <h4 style="font-family:'Poppins';font-weight:600">Questions (<?= count($data['items']) ?>)</h4>
    <button class="adm-btn adm-btn--primary" id="addBtn">+ Add Question</button>
  </div>
  <div id="listContainer"></div>
  <button class="adm-btn adm-btn--primary adm-mt-2" id="saveBtn">Save All Changes</button>
</div>

<script>
const faqData = <?= json_encode($data) ?>;
const fields = ['question','answer'];

function renderItem(item, i) {
  return `
    <input class="adm-input" data-field="question" placeholder="Question" value="${item.question || ''}">
    <textarea class="adm-textarea adm-mt" data-field="answer" placeholder="Answer">${item.answer || ''}</textarea>
  `
}

renderList('listContainer', faqData.items, fields, renderItem)
addItemClick('addBtn', faqData.items, () => ({question:'',answer:''}), 'listContainer', renderItem)

document.getElementById('saveBtn').addEventListener('click', async (e) => {
  faqData.items = collectList('listContainer', fields)
  await saveAndToast('faq', faqData, e.target)
})
</script>
<?php admin_footer(); ?>
