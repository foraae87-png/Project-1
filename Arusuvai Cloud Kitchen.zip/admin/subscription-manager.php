<?php
/** Meal subscription manager — edit plan details and pricing. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('subscriptions');
$default = ['plans' => []];
if (!isset($data['plans'])) $data['plans'] = [];
if (!count($data['plans'])) {
  $data['plans'] = [
    ['name'=>'Weekly Plan','price'=>'999','period'=>'week','desc'=>'7 days of fresh meals','features'=>"1 meal daily for 7 days\nRotating breakfast & lunch menu\nFree home delivery\nPause or skip any day"],
    ['name'=>'Monthly Plan','price'=>'3499','period'=>'month','desc'=>'30 days of homemade goodness','featured'=>true,'features'=>"1 meal daily for 30 days\nFull menu rotation\nFree priority delivery\nPause, skip or modify anytime\nSave ₹500 vs weekly"],
    ['name'=>'Custom Plan','price'=>'Custom','period'=>'','desc'=>'Two meals a day, family plans','features'=>"2 meals daily (breakfast + lunch)\nFamily & couple options\nDiet-specific customisation\nDedicated WhatsApp support"],
  ];
}

admin_header('Meal Plans', 'subscription');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>Meal Subscription Plans</h3>
  <p>Edit the pricing plans shown on the Meal Subscription page.</p>
</div>

<div class="adm-card">
  <div class="adm-flex adm-flex--between adm-mb">
    <h4 style="font-family:'Poppins';font-weight:600">Plans (<?= count($data['plans']) ?>)</h4>
    <button class="adm-btn adm-btn--primary" id="addBtn">+ Add Plan</button>
  </div>
  <div id="listContainer"></div>
  <button class="adm-btn adm-btn--primary adm-mt-2" id="saveBtn">Save All Changes</button>
</div>

<script>
const subData = <?= json_encode($data) ?>;
const fields = ['name','price','period','desc','features','featured'];

function renderItem(item, i) {
  return `
    <div class="adm-grid adm-grid--2">
      <input class="adm-input" data-field="name" placeholder="Plan name" value="${item.name || ''}">
      <input class="adm-input" data-field="price" placeholder="Price (₹)" value="${item.price || ''}">
    </div>
    <div class="adm-grid adm-grid--2 adm-mt">
      <input class="adm-input" data-field="period" placeholder="Period (e.g. /week)" value="${item.period || ''}">
      <input class="adm-input" data-field="desc" placeholder="Short description" value="${item.desc || ''}">
    </div>
    <textarea class="adm-textarea adm-mt" data-field="features" placeholder="One feature per line">${item.features || ''}</textarea>
    <label class="adm-flex adm-mt" style="gap:0.4rem;font-size:0.85rem">
      <input type="checkbox" data-field="featured" ${item.featured?'checked':''}> Featured plan (highlighted)
    </label>
  `
}

renderList('listContainer', subData.plans, fields, renderItem)
addItemClick('addBtn', subData.plans, () => ({name:'',price:'',period:'',desc:'',features:'',featured:false}), 'listContainer', renderItem)

document.getElementById('saveBtn').addEventListener('click', async (e) => {
  const items = collectList('listContainer', fields)
  items.forEach(it => it.featured = it.featured === true || it.featured === 'on' || it.featured === 'true')
  subData.plans = items
  await saveAndToast('subscriptions', subData, e.target)
})
</script>
<?php admin_footer(); ?>
