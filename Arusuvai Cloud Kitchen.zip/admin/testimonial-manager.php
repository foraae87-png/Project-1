<?php
/** Testimonials manager — add/edit/remove customer reviews. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('reviews');
if (!isset($data['items'])) $data['items'] = [];

admin_header('Testimonials', 'testimonial');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>Testimonials Manager</h3>
  <p>Manage customer reviews shown on the homepage and reviews page.</p>
</div>

<div class="adm-card">
  <div class="adm-flex adm-flex--between adm-mb">
    <h4 style="font-family:'Poppins';font-weight:600">Reviews (<?= count($data['items']) ?>)</h4>
    <button class="adm-btn adm-btn--primary" id="addBtn">+ Add Review</button>
  </div>
  <div id="listContainer"></div>
  <button class="adm-btn adm-btn--primary adm-mt-2" id="saveBtn">Save All Changes</button>
</div>

<script>
const revData = <?= json_encode($data) ?>;
const fields = ['name','role','rating','text','avatar','source'];

function renderItem(item, i) {
  return `
    <div class="adm-grid adm-grid--2">
      <input class="adm-input" data-field="name" placeholder="Customer name" value="${item.name || ''}">
      <input class="adm-input" data-field="role" placeholder="Role / context" value="${item.role || ''}">
    </div>
    <div class="adm-grid adm-grid--2 adm-mt">
      <input class="adm-input" data-field="rating" placeholder="Rating (1-5)" type="number" min="1" max="5" value="${item.rating || 5}">
      <input class="adm-input" data-field="source" placeholder="Source (Google/Instagram/WhatsApp)" value="${item.source || 'Google'}">
    </div>
    <textarea class="adm-textarea adm-mt" data-field="text" placeholder="Review text">${item.text || ''}</textarea>
    <input class="adm-input adm-mt" data-field="avatar" placeholder="Avatar image URL" value="${item.avatar || ''}">
  `
}

renderList('listContainer', revData.items, fields, renderItem)
addItemClick('addBtn', revData.items, () => ({name:'',role:'',rating:5,text:'',avatar:'',source:'Google'}), 'listContainer', renderItem)

document.getElementById('saveBtn').addEventListener('click', async (e) => {
  revData.items = collectList('listContainer', fields)
  await saveAndToast('reviews', revData, e.target)
})
</script>
<?php admin_footer(); ?>
