<?php
/** Menu manager — add/edit/remove menu items with category, price, image. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('menu');
if (!isset($data['items'])) $data['items'] = [];

admin_header('Menu Manager', 'menu');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>Menu Manager</h3>
  <p>Add, edit and remove dishes from your menu. Changes save to menu.json.</p>
</div>

<div class="adm-card">
  <div class="adm-flex adm-flex--between adm-mb">
    <h4 style="font-family:'Poppins';font-weight:600">Menu Items (<?= count($data['items']) ?>)</h4>
    <button class="adm-btn adm-btn--primary" id="addBtn">+ Add Item</button>
  </div>
  <div id="listContainer"></div>
  <button class="adm-btn adm-btn--primary adm-mt-2" id="saveBtn">Save All Changes</button>
</div>

<script>
const menuData = <?= json_encode($data) ?>;
const fields = ['name','price','category','description','image','tag'];
const cats = ['breakfast','meals','snacks','drinks'];
const tags = ['', 'Best Seller', 'Veg'];

function renderItem(item, i) {
  return `
    <div class="adm-grid adm-grid--2">
      <input class="adm-input" data-field="name" placeholder="Dish name" value="${item.name || ''}">
      <input class="adm-input" data-field="price" placeholder="₹ Price" value="${item.price || ''}">
    </div>
    <div class="adm-grid adm-grid--2 adm-mt">
      <select class="adm-select" data-field="category">
        ${cats.map(c => `<option value="${c}" ${item.category===c?'selected':''}>${c.charAt(0).toUpperCase()+c.slice(1)}</option>`).join('')}
      </select>
      <select class="adm-select" data-field="tag">
        ${tags.map(t => `<option value="${t}" ${item.tag===t?'selected':''}>${t || 'No tag'}</option>`).join('')}
      </select>
    </div>
    <input class="adm-input adm-mt" data-field="description" placeholder="Short description" value="${item.description || ''}">
    <input class="adm-input adm-mt" data-field="image" placeholder="Image URL" value="${item.image || ''}">
  `
}

renderList('listContainer', menuData.items, fields, renderItem)
addItemClick('addBtn', menuData.items, () => ({name:'',price:'',category:'breakfast',description:'',image:'',tag:''}), 'listContainer', renderItem)

document.getElementById('saveBtn').addEventListener('click', async (e) => {
  menuData.items = collectList('listContainer', fields)
  await saveAndToast('menu', menuData, e.target)
})
</script>
<?php admin_footer(); ?>
