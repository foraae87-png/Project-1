<?php
/**
 * Admin login page — PHP-only authentication.
 * Passwords are never exposed to the browser.
 */

declare(strict_types=1);

require_once __DIR__ . '/backend/config.php';
require_once __DIR__ . '/backend/auth.php';
require_once __DIR__ . '/backend/functions.php';

auth_start();

// Already logged in? Go to dashboard.
if (is_logged_in()) {
    header('Location: /admin/dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if (attempt_login($username, $password)) {
        header('Location: /admin/dashboard.php');
        exit;
    }
    $error = 'Invalid credentials or too many attempts. Please try again later.';
}
?>
<!doctype html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login — Arusuvai</title>
  <link rel="icon" type="image/png" href="/logo.png">
  <link rel="stylesheet" href="/admin/assets/admin.css">
</head>
<body class="adm">
  <div class="adm-login">
    <div class="adm-login__card">
      <div class="adm-login__logo">
        <img src="/logo.png" alt="Arusuvai">
        <div><h1>Arusuvai</h1><small>Admin Panel</small></div>
      </div>
      <form method="post" autocomplete="off">
        <div class="adm-login__error <?= $error ? 'show' : '' ?>"><?= e($error) ?></div>
        <div class="adm-form-group">
          <label for="username">Username</label>
          <input class="adm-input" type="text" id="username" name="username" required autofocus>
        </div>
        <div class="adm-form-group">
          <label for="password">Password</label>
          <input class="adm-input" type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="adm-btn adm-btn--primary adm-btn--block">Sign In</button>
      </form>
      <p class="adm-login__hint">Default: admin / arusuvai123 — change after first login.</p>
    </div>
  </div>
  <script src="/admin/assets/admin.js"></script>
</body>
</html>
