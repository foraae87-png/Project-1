<?php
/** Hero section editor — eyebrow, headline, subheadline, CTA, image, badges. */
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_login();

$data = load_json('hero');
$default = [
  'eyebrow' => 'Freshly Cooked Every Day',
  'headline' => "Authentic South Indian Meals,\nCooked Like Home.",
  'subheadline' => 'Fresh homemade breakfasts, wholesome meal subscriptions, catering and corporate lunch services made with authentic South Indian recipes and delivered with care.',
  'image' => 'https://images.pexels.com/photos/35539315/pexels-photo-35539315.jpeg?auto=compress&cs=tinysrgb&w=900',
  'cta_primary' => 'Order on WhatsApp',
  'cta_secondary' => "View Today's Menu",
];
foreach ($default as $k => $v) if (!isset($data[$k])) $data[$k] = $v;

admin_header('Hero Section', 'hero');
set_admin_js('/admin/assets/manager.js');
?>
<div class="adm-content__head">
  <h3>Hero Section</h3>
  <p>Edit the main banner on your homepage — the first thing visitors see.</p>
</div>

<div class="adm-card" style="max-width:680px">
  <form id="heroForm">
    <div class="adm-form-group">
      <label>Eyebrow Text</label>
      <input class="adm-input" data-field="eyebrow" value="<?= e($data['eyebrow']) ?>">
    </div>
    <div class="adm-form-group">
      <label>Headline</label>
      <textarea class="adm-textarea" data-field="headline"><?= e($data['headline']) ?></textarea>
      <div class="adm-hint">Use a line break for a two-line headline.</div>
    </div>
    <div class="adm-form-group">
      <label>Subheadline</label>
      <textarea class="adm-textarea" data-field="subheadline"><?= e($data['subheadline']) ?></textarea>
    </div>
    <div class="adm-form-group">
      <label>Hero Image URL</label>
      <input class="adm-input" data-field="image" value="<?= e($data['image']) ?>">
      <div class="adm-hint">Paste a URL or upload below.</div>
    </div>
    <div class="adm-form-group">
      <label>Primary Button Text</label>
      <input class="adm-input" data-field="cta_primary" value="<?= e($data['cta_primary']) ?>">
    </div>
    <div class="adm-form-group">
      <label>Secondary Button Text</label>
      <input class="adm-input" data-field="cta_secondary" value="<?= e($data['cta_secondary']) ?>">
    </div>
    <div class="adm-dropzone" id="dropzone">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
      <p>Drag & drop or click to upload hero image</p>
      <input type="file" id="fileInput" accept="image/*" hidden>
    </div>
    <button type="submit" class="adm-btn adm-btn--primary adm-mt">Save Changes</button>
  </form>
</div>

<script>
const heroData = <?= json_encode($data) ?>;
document.getElementById('heroForm').addEventListener('submit', async (e) => {
  e.preventDefault()
  const fields = ['eyebrow','headline','subheadline','image','cta_primary','cta_secondary']
  fields.forEach(f => heroData[f] = document.querySelector(`[data-field="${f}"]`).value)
  const btn = e.target.querySelector('button[type="submit"]')
  await saveAndToast('hero', heroData, btn)
})
initDropzone('dropzone', 'fileInput', 'hero', (url) => {
  document.querySelector('[data-field="image"]').value = url
})
</script>
<?php admin_footer(); ?>
